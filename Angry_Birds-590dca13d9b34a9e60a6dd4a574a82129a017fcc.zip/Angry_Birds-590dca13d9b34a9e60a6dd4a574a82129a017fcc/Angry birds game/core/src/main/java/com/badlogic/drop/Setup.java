package com.badlogic.drop;

public class Setup {
//    private Main game;

    public Setup(Main game){
//        this.game=game;
        Level.createLevels(game);

    }
}
